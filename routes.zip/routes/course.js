/**
 * Created by liuyao on 2017/3/20.
 */
var express = require('express');
var router = express.Router();

router.get('/loadAllCourse', function(req, res, next) {
    var value = {
        success:true,
        list:[
            {id:1,courseName:"架子鼓1"},
            {id:2,courseName:"架子鼓2"},
            {id:3,courseName:"架子鼓3"},
            {id:4,courseName:"架子鼓4"}
        ]
    };
    res.send(value);
});


module.exports = router;

